
// SCORM 1.2 API Wrapper (standardized)
var API = null;
var findAPITries = 0;
var maxTries = 500;

function findAPI(win) {
  while ((win.API == null) && (win.parent != null) && (win.parent != win)) {
    findAPITries++;
    if (findAPITries > maxTries) return null;
    win = win.parent;
  }
  return win.API;
}

function getAPI() {
  if (API != null) return API;
  var theAPI = findAPI(window);
  if ((theAPI == null) && (window.opener != null)) {
    theAPI = findAPI(window.opener);
  }
  if (theAPI != null) API = theAPI;
  return API;
}

function doLMSInitialize() {
  var api = getAPI();
  if (api == null) return false;
  return api.LMSInitialize("") == "true";
}

function doLMSFinish() {
  var api = getAPI();
  if (api == null) return false;
  return api.LMSFinish("") == "true";
}

function doLMSGetValue(name) {
  var api = getAPI();
  if (api == null) return "";
  return api.LMSGetValue(name);
}

function doLMSSetValue(name, value) {
  var api = getAPI();
  if (api == null) return false;
  return api.LMSSetValue(name, value) == "true";
}

function doLMSCommit() {
  var api = getAPI();
  if (api == null) return false;
  return api.LMSCommit("") == "true";
}

function ErrorHandler() {
  var api = getAPI();
  if (api == null) return;
  var errCode = api.LMSGetLastError();
  if (errCode != "0") {
    var errDescription = api.LMSGetErrorString(errCode);
    console.error("SCORM Error: " + errCode + " - " + errDescription);
  }
}
