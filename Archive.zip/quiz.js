
window.onload = function() {
  try {
    doLMSInitialize("");
  } catch (e) {
    console.error("SCORM initialization failed", e);
  }
};

const quizData = [
  {
    question: "Which of the following practices is the MOST secure way to store your passwords?",
    options: [
      "Write them on a sticky note and hide it under your keyboard",
      "Share them only with your manager or with ISBC for backup",
      "Write them on a notebook and keep in your drawer",
      "Use a secure password manager like KeyPass or your passwords app on your phone"
    ],
    answer: 3,
    image: "q1.png"
  },
  {
    question: "True or False: It’s safe to leave printed confidential documents on your desk if you’re stepping away for just a few minutes.",
    options: ["True", "False"],
    answer: 1,
    image: "q2.png"
  },
  {
    question: "You printed a confidential report and forgot to pick it up. What would have best prevented this?",
    options: [
      "Using a shredder before printing",
      "Saving the report to your U: drive",
      "Collect documents immediately after printing",
      "Sending the report to your colleague instead"
    ],
    answer: 2,
    image: "q3.jpg"
  },
  {
    question: "A colleague left their PC unlocked during lunch with sensitive data visible. What should you do?",
    options: [
      "Shut down the PC",
      "Tell IT to disable their account",
      "Print the data on their PC so it’s not lost",
      "Lock their screen with Windows + L and remind them later",
    ],
    answer: 3,
    image: "q4.jpg"
  },
  {
    question: "Why is it not recommended to save confidential files on your desktop or downloads folder?",
    options: [
      "They can be accidentally deleted more easily",
      "They can be printed easily",
      "Files are not backed-up",
      "A virus/malware might be on these folders"
    ],
    answer: 2,
    image: "q5.png"
  },
  {
    question: "What should you do with printed documents containing client information when no longer needed?",
    options: [
      "Crumple then throw in the bin",
      "Use the shredder in the printer area",
      "Tear in half and discard in paper recycle bin",
      "Scan and save before throwing"
    ],
    answer: 1,
    image: "q6.jpg"
  }
];

let currentQuestion = 0;
let userAnswers = [];

function startQuiz() {
  document.getElementById('intro').style.display = 'none';
  document.getElementById('quiz-container').style.display = 'block';
  loadQuestion(currentQuestion);
}

function loadQuestion(index) {
  const quizContainer = document.getElementById('quiz');
  quizContainer.innerHTML = '';
  const q = quizData[index];

  // Progress bar and counter
  const progress = document.getElementById('progress');
  const percent = ((index) / quizData.length) * 100;
  progress.style.width = `${percent}%`;

  const counter = document.getElementById('question-counter');
  counter.innerHTML = `<p style="color: green; font-weight: bold;">Question ${index + 1} of ${quizData.length}</p>`;

  const row = document.createElement('div');
  row.style.display = 'flex';
  row.style.alignItems = 'flex-start';
  row.style.gap = '40px';

  const leftCol = document.createElement('div');
  leftCol.style.flex = '1';

  const qText = document.createElement('h2');
  qText.innerText = q.question;
  leftCol.appendChild(qText);

  q.options.forEach((opt, i) => {
    const label = document.createElement('label');
    label.style.display = 'block';
    label.style.marginTop = '10px';

    const input = document.createElement('input');
    input.type = 'radio';
    input.name = 'option';
    input.value = i;
    if (userAnswers[index] === i) input.checked = true;

    label.appendChild(input);
    label.appendChild(document.createTextNode(' ' + opt));
    leftCol.appendChild(label);
  });

  const errorMsg = document.createElement('p');
  errorMsg.id = 'error-msg';
  errorMsg.style.color = 'red';
  errorMsg.style.marginTop = '10px';
  errorMsg.style.display = 'none';
  leftCol.appendChild(errorMsg);

  const rightCol = document.createElement('div');
  rightCol.style.flex = '1';
  const img = document.createElement('img');
  img.src = q.image || 'images/default.png';
  img.alt = 'Question visual';
  img.style.maxWidth = '100%';
  img.style.borderRadius = '8px';
  img.style.boxShadow = '0 2px 6px rgba(0,0,0,0.1)';
  rightCol.appendChild(img);

  row.appendChild(leftCol);
  row.appendChild(rightCol);
  quizContainer.appendChild(row);

  const navDiv = document.createElement('div');
  navDiv.style.marginTop = '30px';
  navDiv.style.display = 'flex';
  navDiv.style.gap = '15px';

  if (index > 0) {
    const prevBtn = document.createElement('button');
    prevBtn.innerText = 'Previous';
    prevBtn.onclick = () => {
      saveAnswer();
      currentQuestion--;
      loadQuestion(currentQuestion);
    };
    navDiv.appendChild(prevBtn);
  }

  const nextBtn = document.createElement('button');
  nextBtn.innerText = (index < quizData.length - 1) ? 'Next' : 'Submit Quiz';
  nextBtn.onclick = () => {
    if (document.querySelector('input[name="option"]:checked')) {
      saveAnswer();
      if (index < quizData.length - 1) {
        currentQuestion++;
        loadQuestion(currentQuestion);
      } else {
        submitQuiz();
      }
    } else {
      document.getElementById('error-msg').style.display = 'block';
      document.getElementById('error-msg').innerText = "Please select an answer before proceeding.";
    }
  };
  navDiv.appendChild(nextBtn);
  quizContainer.appendChild(navDiv);
}

function saveAnswer() {
  const selected = document.querySelector('input[name="option"]:checked');
  userAnswers[currentQuestion] = selected ? parseInt(selected.value) : null;
}

function submitQuiz() {
  saveAnswer();
  let score = 0;

  for (let i = 0; i < quizData.length; i++) {
    if (userAnswers[i] === quizData[i].answer) score++;
  }

  const scorePercent = Math.round((score / quizData.length) * 100);

  // SCORM Reporting moved to exitQuiz function.

  // Display results
  document.getElementById('quiz-container').style.display = 'none';
  document.getElementById('result-container').style.display = 'block';

  const scoreDiv = document.getElementById('score-display');
  const color = scorePercent >= 80 ? '#28a745' : (scorePercent >= 60 ? '#e0c100' : '#ff4d4f');
  scoreDiv.innerHTML = `<h1 style="color:${color}; font-size: 48px;">Your Score: ${scorePercent}%</h1>`;
}


window.onbeforeunload = exitQuiz;
function exitQuiz() {
  try {
    doLMSSetValue("cmi.core.score.min", "0");
    doLMSSetValue("cmi.core.score.max", "100");
    doLMSSetValue("cmi.core.score.raw", scorePercent.toString());
    doLMSSetValue("cmi.core.lesson_status", scorePercent >= 60 ? "passed" : "failed");
    doLMSCommit("");
    doLMSFinish("");
  } catch (e) {
    console.error("Error sending SCORM score", e);
  }
}
