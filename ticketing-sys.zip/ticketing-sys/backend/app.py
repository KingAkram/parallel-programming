from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from bson import ObjectId
from datetime import datetime
from collections import defaultdict

app = Flask(__name__)
CORS(app)

client = MongoClient("mongodb+srv://akram:akram@cluster0.axhqe1r.mongodb.net/")
db = client.get_database("ticketing")
tickets = db.get_collection("tickets")

@app.route("/tickets", methods=["GET"])
def get_tickets():
    status = request.args.get("status", "open")
    query = {"status": status}
    
    if status == "completed":
        completed_by = request.args.get("completed_by")
        if completed_by:
            query["completed_by"] = completed_by

    result = list(tickets.find(query).sort("receivedAt", -1))
    for r in result:
        r["_id"] = str(r["_id"])
    return jsonify(result)

@app.route("/tickets/<ticket_id>/complete", methods=["PATCH"])
def complete_ticket(ticket_id):
    data = request.json
    name = data.get("completed_by", "Unknown")
    completed_at = datetime.utcnow().isoformat()
    tickets.update_one(
        {"_id": ObjectId(ticket_id)},
        {"$set": {"status": "completed", "completed_by": name, "completed_at": completed_at}}
    )
    return jsonify({"status": "success"})

@app.route("/tickets/<ticket_id>", methods=["DELETE"])
def delete_ticket(ticket_id):
    result = tickets.delete_one({"_id": ObjectId(ticket_id)})
    if result.deleted_count == 1:
        return jsonify({"status": "success", "message": "Ticket deleted"})
    else:
        return jsonify({"status": "error", "message": "Ticket not found"}), 404

@app.route("/dashboard", methods=["GET"])
def get_dashboard_data():
    # Tickets completed by each person
    pipeline_completed_by = [
        {"$match": {"status": "completed", "completed_by": {"$ne": None}}},
        {"$group": {"_id": "$completed_by", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}}
    ]
    completed_by_stats = list(tickets.aggregate(pipeline_completed_by))

    # Tickets created per day
    pipeline_tickets_per_day = [
        {
            "$group": {
                "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": {"$toDate": "$receivedAt"}}},
                "count": {"$sum": 1}
            }
        },
        {"$sort": {"_id": 1}}
    ]
    tickets_per_day = list(tickets.aggregate(pipeline_tickets_per_day))

    # Tickets completed per day
    pipeline_completed_per_day = [
        {"$match": {"status": "completed", "completed_at": {"$ne": None}}},
        {
            "$group": {
                "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": {"$toDate": "$completed_at"}}},
                "count": {"$sum": 1}
            }
        },
        {"$sort": {"_id": 1}}
    ]
    completed_per_day = list(tickets.aggregate(pipeline_completed_per_day))

    return jsonify({
        "completed_by_stats": completed_by_stats,
        "tickets_per_day": tickets_per_day,
        "completed_per_day": completed_per_day
    })

if __name__ == "__main__":
    app.run(debug=True)