from exchangelib import Credentials, Account, Configuration, DELEGATE, Message, FileAttachment, HTMLBody
from exchangelib.protocol import BaseProtocol, NoVerifyHTTPAdapter
from pymongo import MongoClient
import datetime

# Disable SSL verification (only for dev environments!)
BaseProtocol.HTTP_ADAPTER_CLS = NoVerifyHTTPAdapter

# Exchange configuration
credentials = Credentials(username='eltabbaha@bankmed.com.lb', password='YOUR_PASSWORD_HERE')  # Replace with secure method!
config = Configuration(server='10.11.1.222', credentials=credentials)
account = Account(
    primary_smtp_address='isbc@bankmed.com.lb',
    config=config,
    autodiscover=False,
    access_type=DELEGATE
)

# MongoDB setup
client = MongoClient("mongodb://localhost:27017/")
db = client["support_tickets"]
tickets_collection = db["tickets"]

# Read emails from the Inbox
for item in account.inbox.all().order_by('-datetime_received')[:10]:
    if isinstance(item, Message):
        print(f"From: {item.sender.email_address}")
        print(f"Subject: {item.subject}")
        print(f"Body: {item.body[:150]}")
        print(f"Received: {item.datetime_received}")

        ticket = {
            "sender": item.sender.email_address,
            "subject": item.subject,
            "body": str(item.body)[:150],
            "received_time": item.datetime_received.isoformat(),
            "status": "open"
        }
        tickets_collection.insert_one(ticket)
